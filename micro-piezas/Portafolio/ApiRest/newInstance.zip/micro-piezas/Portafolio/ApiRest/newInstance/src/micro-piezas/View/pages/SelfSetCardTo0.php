<?php
    $n2d->subtract();
?>