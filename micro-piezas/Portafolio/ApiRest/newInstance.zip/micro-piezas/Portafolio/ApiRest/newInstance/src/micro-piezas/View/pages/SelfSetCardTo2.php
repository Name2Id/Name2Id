<?php
    $n2d->increase();
?>