<?php

define ('BOTHCN2D','./Name2Id/N2D/ClassN2d.php');
define ('BOTHIN2D','./Name2Id/N2D/InterfaceN2d.php');
/*
define ('','');
define ('','');
define ('','');
define ('',''); 
*/